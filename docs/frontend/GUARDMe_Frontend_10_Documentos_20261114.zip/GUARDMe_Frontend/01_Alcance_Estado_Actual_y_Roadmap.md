# GUARDMe — 01. Alcance, estado actual y hoja de ruta

**Documento:** FE-D01 · **Versión:** 1.0 · **Fecha:** 14 de noviembre de 2026.  
**Origen:** propuesta de frontend v1.1 aprobada por el responsable.  
**Naturaleza:** especificación documental ampliada; no acredita implementación ni pruebas ejecutadas.

## 1. Propósito y forma de lectura

Este documento organiza los diez entregables de frontend y conserva las decisiones de alcance. Debe permitir que diseño, Android, backend y firmware trabajen con el mismo significado de persona, cuidador, incidente y confirmación. El detalle añadido concreta la propuesta aprobada; las recomendaciones nuevas siguen identificadas como propuestas y los puntos abiertos conservan ese estado.

La fuente principal es la [propuesta aprobada](https://chatgpt.com/library?file_id=libfile_ca27f3775390819194d98ece7cfdf85c&account_id=personal). La entrevista de producto determina las reglas funcionales y el código observado determina qué existe. La propuesta de backend es una referencia de coordinación: su recomendación de infraestructura no prueba que esos servicios estén construidos.

### Catálogo y orden recomendado

| Documento | Responsabilidad principal | Lectura relacionada |
|---|---|---|
| [01. Alcance y hoja de ruta](01_Alcance_Estado_Actual_y_Roadmap.md) | Inventario, reglas, dependencias y registro de pendientes | Todos |
| [02. Sistema visual](02_Sistema_Visual_Componentes_y_Accesibilidad.md) | Marca, componentes, adaptación y accesibilidad | 04, 05 y 10 |
| [03. Configuración e identidad](03_Configuracion_Inicial_Identidad_PIN_y_Vinculaciones.md) | Entrada, cuenta, PIN, permisos y vínculos | 08 y 09 |
| [04. Experiencia Persona](04_Experiencia_Movil_Persona.md) | Pantallas y recorridos cotidianos del usuario del bastón | 02, 06 y 07 |
| [05. Experiencia Cuidador](05_Experiencia_Movil_Cuidador.md) | Supervisión, atención y varios perfiles | 03, 06 y 07 |
| [06. Emergencias y seguimiento](06_Emergencias_Llamadas_Atencion_y_Seguimiento.md) | Ventana de caída, llamadas, atención y consultas posteriores | 09 y 10 |
| [07. Recordatorios e información](07_Recordatorios_Compartidos_Historial_y_Ubicacion.md) | Recordatorios, historial, ubicación y telemetría visible | 04, 05 y 09 |
| [08. Arquitectura Android](08_Arquitectura_Android_Stack_y_Organizacion.md) | Stack, capas, estado, navegación y evolución | 03 y 09 |
| [09. Integración y sincronización](09_Integracion_Backend_Baston_Persistencia_y_Sincronizacion.md) | Contratos conceptuales, acuses, persistencia y desconexiones | 06, 07 y 08 |
| [10. Verificación y entrega](10_Verificacion_Criterios_Aceptacion_y_Entrega.md) | Matriz FE-01–FE-21, escenarios y evidencias | Todos |

## 2. Producto y primera versión

GuardMe combina un bastón inteligente y una aplicación Android. La persona lleva el teléfono que actúa como pasarela; el cuidador recibe avisos en otro teléfono. Persona y Cuidador son experiencias móviles de una sola aplicación, con el mismo stack y una densidad de información diferente.

La primera versión debe demostrar un evento real que sale del bastón, llega al teléfono de la persona, se comunica a otro teléfono y queda registrado con la atención del cuidador. Incluye recordatorios y sus cambios compartidos. La ubicación real es un objetivo que puede pasar a la siguiente entrega si no se consigue integrar; esta excepción no se extiende automáticamente a las demás funciones.

| Compromiso | Consecuencia para frontend |
|---|---|
| Detectar posibles caídas | Presentar posibilidad, sin afirmar diagnóstico |
| Esperar 30 segundos | Recuperar el tiempo restante; durante la espera sólo suena el bastón |
| Cancelar desde app o mango | Mostrar un resultado coherente para el mismo episodio |
| Dos contactos, dos intentos por contacto | Presentar orden y resultado de cada intento |
| Detener llamadas al responder | Consumir evidencia real de respuesta; definir tratamiento de buzón |
| «Yo me encargo» cierra | Registrar «Recibió asistencia» sin otra comprobación obligatoria |
| Seguimiento independiente | El incidente cerrado no vuelve a abierto por una consulta de bienestar |
| Confirmar medicamentos desde app | El mango no se presenta como confirmador de dosis |
| Familiar y médico equivalentes | No bloquear funciones por categoría de cuidador |
| Emergencia sin PIN | Separar protección local de sesión y autorización remota |

El panel de soporte es opcional y posterior. React, TypeScript y Vite sólo se conservan como una alternativa para esa interfaz operativa. No se incluye un portal web de cuidado, una aplicación de escritorio ni iOS en la primera entrega.

## 3. Estado base que debe aprovecharse

| Elemento observado | Qué puede reutilizarse | Qué falta demostrar |
|---|---|---|
| Kotlin, Compose y Material 3 | Proyecto y forma de construir pantallas | Compilación reproducible y compatibilidad de herramientas |
| Navigation Compose y ViewModels | Entrada y estado de presentación | Autenticación, restauración duradera y entradas remotas |
| Persona: cuatro pestañas | Organización y componentes | Datos reales, persistencia e integración |
| Cuidador: cinco áreas | Estructura principal | Igualdad de capacidades y múltiples perfiles reales |
| Tokens y fuentes | Paleta, Figtree, Atkinson Hyperlegible | Contraste y usabilidad medidos |
| Reducers y StateFlow | Transiciones locales y observación de estado | Conciliación con hechos del servidor y del bastón |
| DemoHub | Soporte de demostración aislada | No sirve para comunicar teléfonos |
| ESP32 y MPU6050 | Detección local de golpe y buzzer | Validación de caída, enlace y protocolo de cancelación |

Los porcentajes de batería, pasos, firmware y posiciones precargados no son telemetría. La lectura estática tampoco certifica el funcionamiento del botón o del detector. Los documentos describen la base revisada a la fecha de corte; cada implementación posterior debe actualizar su evidencia.

## 4. Brechas y orden de corrección

Primero se debe eliminar la contradicción entre interfaz y producto: quitar restricciones al cuidador médico, corregir la guía del mango y sustituir la secuencia de un solo contacto. Después se conecta cada pantalla a repositorios y hechos persistentes, evitando que una corrección visual se declare integración completa.

El objetivo no es borrar los escenarios de prueba. Deben quedar aislados del uso real, identificados como demostración y sin capacidad para disparar avisos reales por accidente. Las pantallas de producción no deben heredar nombres, tiempos o resultados de ejemplos como si fueran configuración aprobada.

| Brecha | Riesgo visible | Responsable de coordinación |
|---|---|---|
| Cierre sólo en memoria | Otro cuidador ve el incidente abierto | Android y backend |
| Llamada simulada | Se anuncia contacto sin haberlo realizado | Telefonía y Android |
| Cancelación sin acuse | El teléfono muestra silencio mientras el bastón sigue sonando | Firmware y Android |
| Datos antiguos sin fecha | El cuidador interpreta presencia o conexión actual | Android y backend |
| Permisos por categoría | El médico pierde capacidades acordadas | Android y autorización |
| Agenda no persistente | Se pierde un aviso tras reiniciar | Android y backend |

## 5. Matriz de cobertura de la propuesta original

| Sección original | Desarrollo principal |
|---|---|
| 1. Recomendación | D01 y D08 |
| 2. Fuentes y autoridad | D01 y referencias específicas |
| 3. Estado actual | D01, D08 y D10 |
| 4. Interfaces y etapas | D01 y D08 |
| 5. Diseño móvil | D02, D04 y D05 |
| 6. Navegación y configuración | D03, D04, D05 y D08 |
| 7. Emergencias | D06 y D09 |
| 8. Recordatorios, ubicación e historial | D07 |
| 9. Arquitectura e integración | D08 y D09 |
| 10. Stack móvil | D08 |
| 11. Experiencia móvil del cuidador | D05 |
| 12. Estados transversales | D02, D08 y D09 |
| 13. Seguridad y permisos | D03 y D09 |
| 14. Plan de evolución | D01 y D10 |
| 15. Criterios de aceptación | D10 |
| 16. Decisiones abiertas | Registro de este documento y detalle por dominio |
| 17. Archivos y límites de revisión | D01 y D08 |
| 18. Referencias | Fuentes de cada documento y catálogo de D10 |

Esta matriz es el control para evitar que la división deje una sección sin dueño. Los documentos especializados amplían el tema y remiten al dueño de las reglas compartidas.

## 6. Registro único de decisiones pendientes

| ID | Tema por resolver | Dueño del detalle |
|---|---|---|
| P-01 | Método de acceso, recuperación de cuenta e identidad supervisada | D03 |
| P-02 | Longitud, intentos y recuperación del PIN | D03 |
| P-03 | Transporte, posesión, emparejamiento y cambio de pasarela | D03/D09 |
| P-04 | Patrón físico y conciliación de cancelación al vencer la ventana | D06/D09 |
| P-05 | Modalidad de llamadas, respuesta humana y buzón | D06 |
| P-06 | Vía viable para escalamiento automático al 911 | D06 |
| P-07 | Duración, pausas y casos con cero o un contacto | D06 |
| P-08 | Inicio del plazo de posposición y destinatarios del aviso colectivo | D06 |
| P-09 | Segunda consulta, zona horaria y plazo de respuesta del cuidador | D06 |
| P-10 | Edición/desactivación de recordatorios de cuidador por el usuario | D07 |
| P-11 | Posposición, repetición, falta de respuesta y registro asistido | D07 |
| P-12 | Capacidades reales de batería, sensor, luces y sonidos | D07/D09 |
| P-13 | Ubicación: cadencia, precisión, antigüedad y proveedor | D07 |
| P-14 | Retención, datos atrasados y ventana de deduplicación | D07/D09 |
| P-15 | Versiones compatibles, Android objetivo y restricciones verificadas | D08/D10 |
| P-16 | Alcance de panel interno u otras plataformas | D08 |

La aprobación de la propuesta confirma su dirección, pero no convierte una celda pendiente en un valor numérico definido. Las decisiones posteriores deberán registrar fecha, responsable, opción elegida, consecuencias y documentos afectados.

## 7. Hoja de ruta y condiciones de salida

| Etapa | Alcance | Evidencia de salida |
|---|---|---|
| A | Reconciliar reglas y conseguir compilación base | Proyecto reproducible y textos coherentes |
| B | Configuración, sesión, PIN y vinculaciones | Dos instalaciones conservan contextos autorizados |
| C | Evento físico, ventana y cancelación | Un episodio con trazabilidad de bastón a teléfono |
| D | Aviso remoto, llamadas y atención | Cuidador en otro teléfono confirma resultado persistente |
| E | Recordatorios, seguimiento y recuperación | Ocurrencias y plazos sobreviven a pérdida de UI |
| F | Ubicación si es viable | Captura real, consentimiento y antigüedad visibles |
| G | Expansión opcional | Necesidad concreta y alcance separado |

No se asignan semanas ficticias sin disponibilidad del equipo ni validación de hardware. La dependencia de telefonía debe estudiarse temprano: una demostración con marcador manual no cumple por sí sola el requisito automático al 911.

## 8. Control documental y preparación para desarrollo

El paquete conserva la propuesta original sin reemplazarla. Cada documento tiene identificador FE-D01–FE-D10; los criterios aprobados conservan FE-01–FE-21. Las ampliaciones pueden crear comprobaciones de diseño, pero deben enlazarse a un criterio existente o identificarse como propuesta.

Una entrega documental se considera coherente cuando cubre todas las secciones, no introduce un portal del cuidador, distingue demostración de funcionamiento real y mantiene los puntos abiertos visibles. La aceptación del software se controla en D10 y exige evidencias distintas de esta documentación.

**Siguiente lectura:** [D02 — Sistema visual](02_Sistema_Visual_Componentes_y_Accesibilidad.md).
